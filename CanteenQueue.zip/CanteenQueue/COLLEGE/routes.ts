import type { Express } from "express";
import { createServer, type Server } from "http";
import Stripe from "stripe";
import { storage } from "./storage";
import { insertOrderSchema, insertTokenSchema } from "@shared/schema";
import { z } from "zod";

if (!process.env.STRIPE_SECRET_KEY) {
  throw new Error('Missing required Stripe secret: STRIPE_SECRET_KEY');
}

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
  apiVersion: "2025-06-30.basil",
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Get all food items
  app.get("/api/food-items", async (req, res) => {
    try {
      const items = await storage.getAllFoodItems();
      res.json(items);
    } catch (error: any) {
      res.status(500).json({ message: "Error fetching food items: " + error.message });
    }
  });

  // Get food items by category
  app.get("/api/food-items/category/:category", async (req, res) => {
    try {
      const { category } = req.params;
      const items = await storage.getFoodItemsByCategory(category);
      res.json(items);
    } catch (error: any) {
      res.status(500).json({ message: "Error fetching food items: " + error.message });
    }
  });

  // Search food items
  app.get("/api/food-items/search", async (req, res) => {
    try {
      const { q } = req.query;
      if (!q || typeof q !== 'string') {
        return res.status(400).json({ message: "Search query is required" });
      }
      const items = await storage.searchFoodItems(q);
      res.json(items);
    } catch (error: any) {
      res.status(500).json({ message: "Error searching food items: " + error.message });
    }
  });

  // Create payment intent
  app.post("/api/create-payment-intent", async (req, res) => {
    try {
      const { amount, items } = req.body;
      
      if (!amount || !items) {
        return res.status(400).json({ message: "Amount and items are required" });
      }

      const paymentIntent = await stripe.paymentIntents.create({
        amount: Math.round(amount * 100), // Convert to cents
        currency: "inr",
        metadata: {
          items: JSON.stringify(items)
        }
      });

      // Create order record
      const order = await storage.createOrder({
        userId: null, // Anonymous orders for now
        items: JSON.stringify(items),
        totalAmount: amount.toString(),
        paymentIntentId: paymentIntent.id,
        paymentStatus: "pending"
      });

      res.json({ 
        clientSecret: paymentIntent.client_secret,
        orderId: order.id
      });
    } catch (error: any) {
      res.status(500).json({ message: "Error creating payment intent: " + error.message });
    }
  });

  // Confirm payment and generate token
  app.post("/api/confirm-payment", async (req, res) => {
    try {
      const { paymentIntentId } = req.body;
      
      if (!paymentIntentId) {
        return res.status(400).json({ message: "Payment intent ID is required" });
      }

      // Verify payment with Stripe
      const paymentIntent = await stripe.paymentIntents.retrieve(paymentIntentId);
      
      if (paymentIntent.status !== "succeeded") {
        return res.status(400).json({ message: "Payment not successful" });
      }

      // Find order
      const order = await storage.getOrderByPaymentIntent(paymentIntentId);
      if (!order) {
        return res.status(404).json({ message: "Order not found" });
      }

      // Generate unique token number
      const activeTokens = await storage.getActiveTokens();
      const tokenNumber = generateTokenNumber(activeTokens.length);

      // Create token
      const token = await storage.createToken({
        orderId: order.id,
        tokenNumber,
        status: "active",
        estimatedWaitTime: 15 + (activeTokens.length * 5) // Dynamic wait time
      });

      // Update order status
      await storage.updateOrderPaymentStatus(order.id, "completed", tokenNumber);

      res.json({
        success: true,
        tokenNumber,
        estimatedWaitTime: token.estimatedWaitTime,
        orderId: order.id
      });
    } catch (error: any) {
      res.status(500).json({ message: "Error confirming payment: " + error.message });
    }
  });

  // Get active tokens count for queue status
  app.get("/api/queue-status", async (req, res) => {
    try {
      const activeTokens = await storage.getActiveTokens();
      const estimatedWaitTime = Math.max(15, activeTokens.length * 5); // Minimum 15 minutes
      
      res.json({
        activeTokens: activeTokens.length,
        estimatedWaitTime: `${estimatedWaitTime}-${estimatedWaitTime + 5} minutes`
      });
    } catch (error: any) {
      res.status(500).json({ message: "Error fetching queue status: " + error.message });
    }
  });

  // Get token details
  app.get("/api/token/:tokenNumber", async (req, res) => {
    try {
      const { tokenNumber } = req.params;
      const token = await storage.getTokenByNumber(tokenNumber);
      
      if (!token) {
        return res.status(404).json({ message: "Token not found" });
      }

      res.json(token);
    } catch (error: any) {
      res.status(500).json({ message: "Error fetching token: " + error.message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

function generateTokenNumber(queuePosition: number): string {
  const letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
  const letter = letters[Math.floor(Math.random() * letters.length)];
  const number = (queuePosition + 1).toString().padStart(2, '0');
  return `${letter}${number}`;
}
