import { type User, type InsertUser, type FoodItem, type InsertFoodItem, type Order, type InsertOrder, type Token, type InsertToken } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  getAllFoodItems(): Promise<FoodItem[]>;
  getFoodItemsByCategory(category: string): Promise<FoodItem[]>;
  getFoodItem(id: string): Promise<FoodItem | undefined>;
  searchFoodItems(query: string): Promise<FoodItem[]>;
  
  createOrder(order: InsertOrder): Promise<Order>;
  getOrder(id: string): Promise<Order | undefined>;
  getOrderByPaymentIntent(paymentIntentId: string): Promise<Order | undefined>;
  updateOrderPaymentStatus(id: string, status: string, tokenNumber?: string): Promise<Order | undefined>;
  
  createToken(token: InsertToken): Promise<Token>;
  getActiveTokens(): Promise<Token[]>;
  getTokenByNumber(tokenNumber: string): Promise<Token | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private foodItems: Map<string, FoodItem>;
  private orders: Map<string, Order>;
  private tokens: Map<string, Token>;

  constructor() {
    this.users = new Map();
    this.foodItems = new Map();
    this.orders = new Map();
    this.tokens = new Map();
    
    // Initialize with sample food items
    this.initializeFoodItems();
  }

  private initializeFoodItems() {
    const sampleItems: FoodItem[] = [
      {
        id: "1",
        name: "Masala Dosa Set",
        description: "Crispy dosa with spiced potato filling, served with sambar and coconut chutney",
        price: "45.00",
        category: "breakfast",
        imageUrl: "https://images.unsplash.com/photo-1589301760014-d929f3979dbc?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        available: true,
        rating: "4.5",
        reviewCount: 120,
      },
      {
        id: "2",
        name: "Idli Sambar (4 pcs)",
        description: "Soft steamed rice cakes served with lentil sambar and chutneys",
        price: "35.00",
        category: "breakfast",
        imageUrl: "https://images.unsplash.com/photo-1606491956689-2ea866880c84?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        available: true,
        rating: "4.3",
        reviewCount: 95,
      },
      {
        id: "3",
        name: "Vegetable Upma",
        description: "Healthy semolina preparation with mixed vegetables and spices",
        price: "30.00",
        category: "breakfast",
        imageUrl: "https://images.unsplash.com/photo-1596797038530-2c107229654b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        available: false,
        rating: "4.1",
        reviewCount: 68,
      },
      {
        id: "4",
        name: "Kanda Poha",
        description: "Flattened rice with onions, peanuts and aromatic spices",
        price: "25.00",
        category: "breakfast",
        imageUrl: "https://pixabay.com/get/ga690fc5b197aca6020223666a98fd8e1dcd7dd0530ae4f1a3041c9b49a775a3df023ef60f09a6f5c5a9213102a36062d76315c1bcd9889eff44ed3509e948b4c_1280.jpg",
        available: true,
        rating: "4.4",
        reviewCount: 89,
      },
      {
        id: "5",
        name: "Gujarati Thali",
        description: "Complete meal with rice, dal, vegetables, chapati, papad and pickle",
        price: "85.00",
        category: "lunch",
        imageUrl: "https://images.unsplash.com/photo-1565557623262-b51c2513a641?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        available: true,
        rating: "4.6",
        reviewCount: 245,
      },
      {
        id: "6",
        name: "Veg Biryani",
        description: "Aromatic basmati rice with mixed vegetables, served with raita",
        price: "75.00",
        category: "lunch",
        imageUrl: "https://pixabay.com/get/ga8d748866aae709dc39dacad3934896c230d74e18e6c53238f9e5afb743347d28c60ba406a51f037a69c1db8ac8c2011058ef416eb8b5cbb41d232a74ec7cc8d_1280.jpg",
        available: true,
        rating: "4.4",
        reviewCount: 189,
      },
      {
        id: "7",
        name: "Veg Samosa (2 pcs)",
        description: "Crispy pastry filled with spiced potatoes and green peas",
        price: "20.00",
        category: "snacks",
        imageUrl: "https://images.unsplash.com/photo-1601050690597-df0568f70950?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        available: true,
        rating: "4.2",
        reviewCount: 156,
      },
      {
        id: "8",
        name: "Pav Bhaji",
        description: "Spiced vegetable curry served with buttered bread rolls",
        price: "55.00",
        category: "snacks",
        imageUrl: "https://images.unsplash.com/photo-1606491956689-2ea866880c84?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        available: true,
        rating: "4.5",
        reviewCount: 203,
      },
      {
        id: "9",
        name: "Bhel Puri",
        description: "Crunchy mixture of puffed rice, vegetables and tangy chutneys",
        price: "35.00",
        category: "snacks",
        imageUrl: "https://pixabay.com/get/g42ecb245230e13a894605e64d8551b0451e5361d13556c3bbf0e74b06be486178a386b611778c4fcfd95438feecf190d4b85c2885fe317da35aafe66ed79d7a9_1280.jpg",
        available: true,
        rating: "4.3",
        reviewCount: 134,
      },
      {
        id: "10",
        name: "Dal Tadka Rice",
        description: "Tempered lentils served with steamed rice and chapati",
        price: "60.00",
        category: "dinner",
        imageUrl: "https://images.unsplash.com/photo-1585937421612-70a008356fbe?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        available: true,
        rating: "4.4",
        reviewCount: 178,
      },
      {
        id: "11",
        name: "Paneer Butter Masala",
        description: "Rich cottage cheese curry in tomato-butter gravy with naan",
        price: "95.00",
        category: "dinner",
        imageUrl: "https://images.unsplash.com/photo-1585937421612-70a008356fbe?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        available: true,
        rating: "4.7",
        reviewCount: 267,
      },
    ];

    sampleItems.forEach(item => {
      this.foodItems.set(item.id, item);
    });
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getAllFoodItems(): Promise<FoodItem[]> {
    return Array.from(this.foodItems.values());
  }

  async getFoodItemsByCategory(category: string): Promise<FoodItem[]> {
    return Array.from(this.foodItems.values()).filter(
      item => item.category === category
    );
  }

  async getFoodItem(id: string): Promise<FoodItem | undefined> {
    return this.foodItems.get(id);
  }

  async searchFoodItems(query: string): Promise<FoodItem[]> {
    const searchTerm = query.toLowerCase();
    return Array.from(this.foodItems.values()).filter(
      item => 
        item.name.toLowerCase().includes(searchTerm) ||
        item.description.toLowerCase().includes(searchTerm)
    );
  }

  async createOrder(insertOrder: InsertOrder): Promise<Order> {
    const id = randomUUID();
    const order: Order = { 
      ...insertOrder, 
      id,
      userId: insertOrder.userId || null,
      paymentStatus: insertOrder.paymentStatus || "pending",
      tokenNumber: insertOrder.tokenNumber || null,
      createdAt: new Date()
    };
    this.orders.set(id, order);
    return order;
  }

  async getOrder(id: string): Promise<Order | undefined> {
    return this.orders.get(id);
  }

  async getOrderByPaymentIntent(paymentIntentId: string): Promise<Order | undefined> {
    return Array.from(this.orders.values()).find(
      order => order.paymentIntentId === paymentIntentId
    );
  }

  async updateOrderPaymentStatus(id: string, status: string, tokenNumber?: string): Promise<Order | undefined> {
    const order = this.orders.get(id);
    if (order) {
      const updatedOrder = { 
        ...order, 
        paymentStatus: status,
        tokenNumber: tokenNumber || order.tokenNumber
      };
      this.orders.set(id, updatedOrder);
      return updatedOrder;
    }
    return undefined;
  }

  async createToken(insertToken: InsertToken): Promise<Token> {
    const id = randomUUID();
    const token: Token = { 
      ...insertToken, 
      id,
      status: insertToken.status || "active",
      estimatedWaitTime: insertToken.estimatedWaitTime || null,
      createdAt: new Date()
    };
    this.tokens.set(id, token);
    return token;
  }

  async getActiveTokens(): Promise<Token[]> {
    return Array.from(this.tokens.values()).filter(
      token => token.status === "active"
    );
  }

  async getTokenByNumber(tokenNumber: string): Promise<Token | undefined> {
    return Array.from(this.tokens.values()).find(
      token => token.tokenNumber === tokenNumber
    );
  }
}

export const storage = new MemStorage();
