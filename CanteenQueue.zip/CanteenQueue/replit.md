# Food Ordering System

## Overview

This is a full-stack food ordering application built with React frontend and Express.js backend. The system allows customers to browse a food menu, add items to cart, make payments via Stripe, and receive order tokens for pickup. It features a modern UI with category filtering, search functionality, and real-time payment processing.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

The application follows a monorepo structure with clear separation between client and server code:

- **Frontend**: React with TypeScript, using Vite as the build tool
- **Backend**: Express.js server with TypeScript
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Payment Processing**: Stripe integration for secure payment handling
- **UI Framework**: Radix UI components with Tailwind CSS for styling

## Key Components

### Frontend Architecture
- **React SPA**: Single-page application using Wouter for routing
- **State Management**: TanStack Query for server state management
- **UI Components**: Comprehensive set of shadcn/ui components built on Radix UI
- **Styling**: Tailwind CSS with CSS variables for theming
- **Payment UI**: Stripe Elements integration for secure payment forms

### Backend Architecture
- **Express Server**: RESTful API with middleware for logging and error handling
- **Storage Layer**: Abstracted storage interface with in-memory implementation
- **Route Handlers**: Organized API endpoints for food items, orders, and payments
- **Stripe Integration**: Server-side payment processing and webhook handling

### Database Schema
The application defines four main entities:
- **Users**: Customer accounts with username/password
- **Food Items**: Menu items with categories, pricing, and availability
- **Orders**: Customer orders with payment tracking
- **Tokens**: Order pickup tokens with queue management

### UI Components Structure
- **Menu Display**: Category filtering and search functionality
- **Shopping Cart**: Bottom bar with item management
- **Payment Flow**: Modal-based checkout with Stripe integration
- **Token Display**: Order confirmation with pickup information

## Data Flow

1. **Menu Browsing**: Frontend fetches food items from `/api/food-items` endpoint
2. **Cart Management**: Local state management for shopping cart operations
3. **Payment Processing**: 
   - Create payment intent on backend
   - Process payment using Stripe Elements on frontend
   - Update order status and generate token upon successful payment
4. **Order Tracking**: Real-time updates on order status and queue information

## External Dependencies

### Payment Processing
- **Stripe**: Handles all payment processing with strong security standards
- **Environment**: Requires `STRIPE_SECRET_KEY` and `VITE_STRIPE_PUBLIC_KEY`

### Database
- **Neon Database**: Serverless PostgreSQL provider
- **Drizzle ORM**: Type-safe database operations with schema migrations
- **Environment**: Requires `DATABASE_URL` for database connection

### UI Libraries
- **Radix UI**: Accessible component primitives
- **Tailwind CSS**: Utility-first CSS framework
- **Lucide React**: Icon library for consistent iconography

## Deployment Strategy

### Development
- **Vite Dev Server**: Hot module replacement for frontend development
- **TSX**: Direct TypeScript execution for backend development
- **Environment**: Uses NODE_ENV=development for development-specific features

### Production Build
- **Frontend**: Vite builds optimized static assets
- **Backend**: ESBuild bundles server code for Node.js execution
- **Assets**: Static files served from dist/public directory

### Environment Configuration
- Database connection via DATABASE_URL
- Stripe configuration via API keys
- Development vs production environment detection
- Replit-specific tooling integration for cloud development

The application is designed to be easily deployable on platforms like Replit, with proper environment variable management and build processes for both development and production environments.