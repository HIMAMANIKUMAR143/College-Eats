import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Search, Utensils, ShoppingCart, Clock } from "lucide-react";
import { FoodItem } from "@shared/schema";
import MenuCard from "@/components/menu-card";
import CategoryFilter from "@/components/category-filter";
import CartBottomBar from "@/components/cart-bottom-bar";
import PaymentModal from "@/components/payment-modal";
import TokenModal from "@/components/token-modal";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface CartItem {
  id: string;
  name: string;
  price: string;
  quantity: number;
}

export default function Home() {
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [showTokenModal, setShowTokenModal] = useState(false);
  const [clientSecret, setClientSecret] = useState("");
  const [tokenData, setTokenData] = useState<any>(null);
  
  const { toast } = useToast();

  // Fetch food items
  const { data: foodItems = [], isLoading } = useQuery<FoodItem[]>({
    queryKey: ['/api/food-items'],
  });

  // Fetch queue status
  const { data: queueStatus } = useQuery<{ estimatedWaitTime: string; activeTokens: number }>({
    queryKey: ['/api/queue-status'],
    refetchInterval: 30000, // Refetch every 30 seconds
  });

  // Filter food items based on category and search
  const filteredItems = foodItems.filter(item => {
    const matchesCategory = selectedCategory === 'all' || item.category === selectedCategory;
    const matchesSearch = searchQuery === '' || 
      item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.description.toLowerCase().includes(searchQuery.toLowerCase());
    
    return matchesCategory && matchesSearch;
  });

  const addToCart = (item: FoodItem) => {
    if (!item.available) {
      toast({
        title: "Item Unavailable",
        description: "This item is currently out of stock.",
        variant: "destructive",
      });
      return;
    }

    setCartItems(prev => {
      const existingItem = prev.find(cartItem => cartItem.id === item.id);
      if (existingItem) {
        return prev.map(cartItem =>
          cartItem.id === item.id
            ? { ...cartItem, quantity: cartItem.quantity + 1 }
            : cartItem
        );
      } else {
        return [...prev, {
          id: item.id,
          name: item.name,
          price: item.price,
          quantity: 1,
        }];
      }
    });

    toast({
      title: "Added to Cart",
      description: `${item.name} has been added to your cart.`,
    });
  };

  const proceedToPayment = async () => {
    const totalAmount = cartItems.reduce((sum, item) => sum + (parseFloat(item.price) * item.quantity), 0);
    
    try {
      const response = await apiRequest("POST", "/api/create-payment-intent", {
        amount: totalAmount,
        items: cartItems,
      });
      
      const data = await response.json();
      setClientSecret(data.clientSecret);
      setShowPaymentModal(true);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to initialize payment. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handlePaymentSuccess = (data: any) => {
    setTokenData(data);
    setShowTokenModal(true);
    setCartItems([]); // Clear cart after successful payment
    
    toast({
      title: "Payment Successful",
      description: `Your token ${data.tokenNumber} has been generated!`,
    });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-24">
      {/* Header */}
      <header className="bg-white shadow-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-3">
              <div className="bg-primary text-white p-2 rounded-lg">
                <Utensils className="w-6 h-6" />
              </div>
              <h1 className="text-xl font-bold text-gray-900">CampusEats</h1>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="relative">
                <ShoppingCart className="w-6 h-6 text-gray-600" />
                {cartItems.length > 0 && (
                  <Badge className="absolute -top-2 -right-2 bg-primary text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                    {cartItems.reduce((sum, item) => sum + item.quantity, 0)}
                  </Badge>
                )}
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Search Bar */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="relative">
            <Input
              type="text"
              placeholder="Search for delicious food..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 pr-4 py-3"
            />
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          </div>
        </div>
      </div>

      {/* Category Filters */}
      <CategoryFilter
        selectedCategory={selectedCategory}
        onCategoryChange={setSelectedCategory}
      />

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* Queue Status Banner */}
        {queueStatus && (
          <div className="mb-6 bg-gradient-to-r from-orange-100 to-orange-200 border border-orange-300 rounded-lg p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <Clock className="text-orange-600 w-5 h-5" />
                <div>
                  <h3 className="font-semibold text-gray-900">Current Queue Status</h3>
                  <p className="text-gray-600">
                    Estimated wait time: <span className="font-medium text-orange-600">{queueStatus.estimatedWaitTime}</span>
                  </p>
                </div>
              </div>
              <div className="text-right">
                <div className="text-2xl font-bold text-orange-600">{queueStatus.activeTokens}</div>
                <div className="text-sm text-gray-600">Active Tokens</div>
              </div>
            </div>
          </div>
        )}

        {/* Food Items Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          {filteredItems.map((item) => (
            <MenuCard
              key={item.id}
              item={item}
              onAddToCart={addToCart}
            />
          ))}
        </div>

        {filteredItems.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-500 text-lg">No items found matching your search.</p>
          </div>
        )}
      </main>

      {/* Cart Bottom Bar */}
      <CartBottomBar
        cartItems={cartItems}
        onProceedToPayment={proceedToPayment}
      />

      {/* Payment Modal */}
      <PaymentModal
        isOpen={showPaymentModal}
        onClose={() => setShowPaymentModal(false)}
        cartItems={cartItems}
        clientSecret={clientSecret}
        onPaymentSuccess={handlePaymentSuccess}
      />

      {/* Token Modal */}
      <TokenModal
        isOpen={showTokenModal}
        onClose={() => setShowTokenModal(false)}
        tokenData={tokenData}
      />
    </div>
  );
}
