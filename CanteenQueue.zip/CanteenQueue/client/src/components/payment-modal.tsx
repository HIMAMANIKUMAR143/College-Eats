import { useState } from "react";
import { Elements, PaymentElement, useStripe, useElements } from '@stripe/react-stripe-js';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Lock, CreditCard, Smartphone } from "lucide-react";
import { stripePromise } from "@/lib/stripe";

interface CartItem {
  id: string;
  name: string;
  price: string;
  quantity: number;
}

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  clientSecret: string;
  onPaymentSuccess: (tokenData: any) => void;
}

function PaymentForm({ cartItems, onPaymentSuccess, onClose }: {
  cartItems: CartItem[];
  onPaymentSuccess: (tokenData: any) => void;
  onClose: () => void;
}) {
  const stripe = useStripe();
  const elements = useElements();
  const [isProcessing, setIsProcessing] = useState(false);

  const totalAmount = cartItems.reduce((sum, item) => sum + (parseFloat(item.price) * item.quantity), 0);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!stripe || !elements) {
      return;
    }

    setIsProcessing(true);

    try {
      const { error, paymentIntent } = await stripe.confirmPayment({
        elements,
        redirect: 'if_required',
      });

      if (error) {
        console.error('Payment failed:', error);
        return;
      }

      if (paymentIntent && paymentIntent.status === 'succeeded') {
        // Confirm payment with backend
        const response = await fetch('/api/confirm-payment', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            paymentIntentId: paymentIntent.id,
          }),
        });

        const tokenData = await response.json();
        
        if (tokenData.success) {
          onPaymentSuccess(tokenData);
          onClose();
        }
      }
    } catch (error) {
      console.error('Payment error:', error);
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {/* Order Summary */}
      <Card className="bg-gray-50">
        <CardContent className="p-4">
          <h3 className="font-semibold text-gray-900 mb-2">Order Summary</h3>
          <div className="space-y-2 text-sm">
            {cartItems.map((item) => (
              <div key={item.id} className="flex justify-between">
                <span>{item.name} x{item.quantity}</span>
                <span>₹{(parseFloat(item.price) * item.quantity).toFixed(2)}</span>
              </div>
            ))}
            <div className="border-t pt-2 flex justify-between font-semibold">
              <span>Total Amount</span>
              <span className="text-primary">₹{totalAmount.toFixed(2)}</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Payment Method */}
      <div>
        <h3 className="font-semibold text-gray-900 mb-3">Payment Method</h3>
        <div className="space-y-2">
          <div className="flex items-center p-3 border border-gray-200 rounded-lg bg-gray-50">
            <CreditCard className="w-5 h-5 text-primary mr-3" />
            <span>Debit/Credit Card</span>
          </div>
        </div>
      </div>

      {/* Stripe Payment Element */}
      <div className="p-4 border border-gray-200 rounded-lg">
        <PaymentElement />
      </div>

      <Button 
        type="submit"
        disabled={!stripe || isProcessing}
        className="w-full bg-green-600 hover:bg-green-700 text-white py-3 rounded-lg font-semibold"
      >
        <Lock className="w-4 h-4 mr-2" />
        {isProcessing ? 'Processing...' : `Pay ₹${totalAmount.toFixed(2)} Securely`}
      </Button>
      
      <p className="text-xs text-gray-500 text-center">
        Your payment is secured with SSL encryption
      </p>
    </form>
  );
}

export default function PaymentModal({ isOpen, onClose, cartItems, clientSecret, onPaymentSuccess }: PaymentModalProps) {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Payment Details</DialogTitle>
        </DialogHeader>
        
        {clientSecret && (
          <Elements 
            stripe={stripePromise} 
            options={{ clientSecret }}
          >
            <PaymentForm 
              cartItems={cartItems}
              onPaymentSuccess={onPaymentSuccess}
              onClose={onClose}
            />
          </Elements>
        )}
      </DialogContent>
    </Dialog>
  );
}
