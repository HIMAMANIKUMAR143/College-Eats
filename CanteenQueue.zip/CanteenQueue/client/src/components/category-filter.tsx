import { Button } from "@/components/ui/button";
import { Coffee, Utensils, Pizza, Cookie } from "lucide-react";

interface CategoryFilterProps {
  selectedCategory: string;
  onCategoryChange: (category: string) => void;
}

export default function CategoryFilter({ selectedCategory, onCategoryChange }: CategoryFilterProps) {
  const categories = [
    { id: 'all', name: 'All Items', icon: null, color: 'bg-primary' },
    { id: 'breakfast', name: 'Breakfast', icon: Coffee, color: 'bg-red-500' },
    { id: 'lunch', name: 'Lunch', icon: Utensils, color: 'bg-blue-500' },
    { id: 'dinner', name: 'Dinner', icon: Pizza, color: 'bg-purple-500' },
    { id: 'snacks', name: 'Snacks', icon: Cookie, color: 'bg-teal-500' },
  ];

  return (
    <div className="bg-white border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <div className="flex space-x-3 overflow-x-auto scrollbar-hide">
          {categories.map((category) => {
            const Icon = category.icon;
            const isSelected = selectedCategory === category.id;
            
            return (
              <Button
                key={category.id}
                variant={isSelected ? "default" : "outline"}
                onClick={() => onCategoryChange(category.id)}
                className={`flex-shrink-0 px-6 py-2 rounded-full font-medium transition-colors ${
                  isSelected 
                    ? `${category.color} text-white hover:${category.color}/90` 
                    : `bg-${category.color}/10 text-${category.color} border-${category.color} hover:${category.color} hover:text-white`
                }`}
              >
                {Icon && <Icon className="w-4 h-4 mr-2" />}
                {category.name}
              </Button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
