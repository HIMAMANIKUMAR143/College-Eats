import { Button } from "@/components/ui/button";
import { ShoppingCart } from "lucide-react";

interface CartItem {
  id: string;
  name: string;
  price: string;
  quantity: number;
}

interface CartBottomBarProps {
  cartItems: CartItem[];
  onProceedToPayment: () => void;
}

export default function CartBottomBar({ cartItems, onProceedToPayment }: CartBottomBarProps) {
  const totalItems = cartItems.reduce((sum, item) => sum + item.quantity, 0);
  const totalAmount = cartItems.reduce((sum, item) => sum + (parseFloat(item.price) * item.quantity), 0);

  if (cartItems.length === 0) {
    return null;
  }

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 p-4 z-40">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <ShoppingCart className="w-5 h-5 text-primary" />
          <div>
            <div className="font-semibold text-gray-900">
              {totalItems} item{totalItems !== 1 ? 's' : ''}
            </div>
            <div className="text-sm text-gray-600">
              Total: <span className="font-semibold text-primary">₹{totalAmount.toFixed(2)}</span>
            </div>
          </div>
        </div>
        <Button 
          onClick={onProceedToPayment}
          className="bg-primary text-white px-6 py-3 rounded-lg font-semibold hover:bg-primary/90"
        >
          Pay & Book Token
        </Button>
      </div>
    </div>
  );
}
