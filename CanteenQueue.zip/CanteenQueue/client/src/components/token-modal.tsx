import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { CheckCircle, Download, Clock } from "lucide-react";

interface TokenModalProps {
  isOpen: boolean;
  onClose: () => void;
  tokenData: {
    tokenNumber: string;
    estimatedWaitTime: number;
    orderId: string;
  } | null;
}

export default function TokenModal({ isOpen, onClose, tokenData }: TokenModalProps) {
  const handleDownloadReceipt = () => {
    // TODO: Implement receipt download functionality
    console.log('Download receipt for order:', tokenData?.orderId);
  };

  if (!tokenData) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <div className="text-center p-6">
          <div className="bg-green-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
            <CheckCircle className="w-8 h-8 text-green-600" />
          </div>
          
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Payment Successful!</h2>
          <p className="text-gray-600 mb-6">Your order has been confirmed and token generated</p>
          
          <Card className="bg-primary/10 mb-6">
            <CardContent className="p-6">
              <div className="text-primary text-4xl font-bold mb-2">
                {tokenData.tokenNumber}
              </div>
              <div className="text-gray-600 mb-2">Your Token Number</div>
              <div className="flex items-center justify-center text-sm text-gray-500">
                <Clock className="w-4 h-4 mr-1" />
                Estimated wait time: {tokenData.estimatedWaitTime} minutes
              </div>
            </CardContent>
          </Card>
          
          <div className="space-y-3">
            <Button 
              onClick={handleDownloadReceipt}
              variant="outline"
              className="w-full"
            >
              <Download className="w-4 h-4 mr-2" />
              Download Receipt
            </Button>
            <Button 
              onClick={onClose}
              className="w-full bg-primary hover:bg-primary/90"
            >
              Continue Browsing
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
