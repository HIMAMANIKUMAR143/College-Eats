import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Star, Plus } from "lucide-react";
import { FoodItem } from "@shared/schema";

interface MenuCardProps {
  item: FoodItem;
  onAddToCart: (item: FoodItem) => void;
}

export default function MenuCard({ item, onAddToCart }: MenuCardProps) {
  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'breakfast': return 'bg-red-500';
      case 'lunch': return 'bg-blue-500';
      case 'dinner': return 'bg-purple-500';
      case 'snacks': return 'bg-teal-500';
      default: return 'bg-gray-500';
    }
  };

  const getAvailabilityColor = (available: boolean) => {
    return available ? 'bg-green-500' : 'bg-red-500';
  };

  const getAvailabilityText = (available: boolean) => {
    return available ? 'Available' : 'Out of Stock';
  };

  return (
    <Card className="overflow-hidden hover:shadow-lg transition-shadow duration-300">
      <div className="relative">
        <img 
          src={item.imageUrl} 
          alt={item.name}
          className="w-full h-48 object-cover"
        />
        <Badge 
          className={`absolute top-3 left-3 text-white text-xs font-medium ${getCategoryColor(item.category)}`}
        >
          {item.category.charAt(0).toUpperCase() + item.category.slice(1)}
        </Badge>
        <Badge 
          className={`absolute top-3 right-3 text-white text-xs font-medium ${getAvailabilityColor(item.available!)}`}
        >
          {getAvailabilityText(item.available!)}
        </Badge>
      </div>
      
      <CardContent className="p-4">
        <h3 className="font-semibold text-lg text-gray-900 mb-1">{item.name}</h3>
        <p className="text-gray-600 text-sm mb-3 line-clamp-2">{item.description}</p>
        
        <div className="flex items-center justify-between mb-3">
          <span className="text-2xl font-bold text-primary">₹{item.price}</span>
          <div className="flex items-center space-x-1">
            <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
            <span className="text-sm text-gray-600">{item.rating}</span>
            <span className="text-sm text-gray-400">({item.reviewCount})</span>
          </div>
        </div>
        
        <Button 
          onClick={() => onAddToCart(item)}
          disabled={!item.available}
          className="w-full bg-primary hover:bg-primary/90 text-white"
        >
          <Plus className="w-4 h-4 mr-2" />
          Add to Cart
        </Button>
      </CardContent>
    </Card>
  );
}
